"""The :mod:`.paper_muncher.frameworks` module provides
integration with popular web frameworks.
Currently supported frameworks are:
- Flask
- Quart
- FastAPI
- Django

- generic WSGI applications
- generic ASGI applications
"""
