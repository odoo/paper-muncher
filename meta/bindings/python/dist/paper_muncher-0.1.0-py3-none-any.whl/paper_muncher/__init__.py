from .autochronous import render, rendered
from .asynchronous import render as async_render, rendered as async_rendered
from .synchronous import render as sync_render, rendered as sync_rendered
from .binary import can_use_paper_muncher
